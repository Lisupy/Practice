Io Language for Windows (32-bit/64-bit)
Binary provided by the iobin project, http://iobin.suspended-chord.info/
-->Jacob Peck

These binaries are provided with absolutely ZERO warranty.
Use at your own risk.
-----

Instructions:
1) Extract the .exe from the downloaded file.
2) Run the .exe.  It'll ask you for a location to extract into.
   Choose any location, it doesn't matter where you wish to install Io.
3) Run io.exe from the bin directory in the directory created by the extractor.
   You're good to go!

~20120430
