module Main where

    double x = x + x
