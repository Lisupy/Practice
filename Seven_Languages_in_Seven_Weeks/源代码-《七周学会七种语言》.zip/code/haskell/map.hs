module Main where
    squareAll list = map square list
        where square x = x * x