module Main where
    prod :: Int -> Int -> Int
    prod x y = x * y
    double = prod 2
